﻿using System;

namespace SwiftDB
{
    internal class Configuration
    {
        internal static string ConnectionString
                   => "Server=.;Database=IcardSwiftDb;Integrated Security=True;";
    }
}
