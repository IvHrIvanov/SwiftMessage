﻿namespace Icard.SwiftParse.UserHeaderBlock
{
    public interface IUserHeaderBlock
    { 
        public string BankingPriorityCode { get; set; }
        public string MessageUserReferenc { get; set; }
      
    }
}